                                  
                                      ██████████                                        
                                    ██░░░░░░░░░░██                                      
                                    ██░░░░░░░░░░░░██                                    
                                  ██░░██░░░░░░██░░██                                    
                                  ██░░██░░░░░░██░░▒▒██                                  
                                  ██░░░░░░░░░░░░░░▒▒██                                  
                                    ██▒▒▒▒▒▒▒▒▒▒▒▒██                                    
                                      ██████████████                                    
                                  ████░░░░██░░░░▒▒████                                  
                                ██░░░░░░██░░░░░░▒▒██▒▒██                                
                              ██░░░░██▒▒▒▒▒▒▒▒▒▒██░░▒▒▒▒██                              
                              ██▒▒░░░░██████████░░░░▒▒██▒▒██                            
                              ██▒▒░░░░░░░░░░░░░░░░░░▒▒██▒▒██                            
                                ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒████▒▒██                            
                                  ██████████████████    ██                              
                                                                                        
                                                                                        
                                                                                        
                                                                                        
pip3 install -r requirements.txt  or  pip install -r requirements.txt

wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb

apt-get install ./google-chrome-stable_current_amd64.deb

Ou você pode executar um comando para fazer as instalações completa (recomendo copiar os comandos em vez de apenas um comando)

python3 setup.py (Esse comando vai executar todos os comando a cima. Como dito, recomendo copiar um por um.)

python3 main.py (para executar a ferramenta)